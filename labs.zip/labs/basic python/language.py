import sys
import re
if len(sys.argv)==3:
    vocabulary=set()
    with open("translations.csv", "r") as file:
        for line in file:
            parts = list(line.strip().split(","))
            if parts[0] == sys.argv[2]:
                vocabulary.add(parts[1])
            if parts[2] == sys.argv[2]:
                vocabulary.add(parts[3])
    result=list(vocabulary)
    result.sort(reverse=True) 
    print(result)    
def languageconv():
    convert=set()
    with open("translations.csv", "r") as file:
        for line in file:
            parts = list(line.strip().split(","))
            lang1 = sys.argv[2]
            lang2 = sys.argv[3]
            if parts[0] == lang1 and parts[2] == lang2:
                tup=(parts[1],parts[3])
                convert.add(tup)
            if parts[0] == lang2 and parts[2] == lang1:
                tup=(parts[3],parts[1])
                convert.add(tup)
            if parts[0] == lang1 and parts[2] != lang2:
                pattern=parts[3]
                word=parts[1]
                with open("translations.csv", "r") as file1:
                    for line1 in file1:
                        parts1 = list(line1.strip().split(","))
                        if parts1[1] == pattern and parts1[3] != word:
                            tup=(parts[1],parts1[3])
                            convert.add(tup)
                        if parts1[3] == pattern and parts1[1] != word:
                            tup=(parts[1],parts1[1])
                            convert.add(tup)
            if parts[2] == lang1 and parts[0] != lang2:
                pattern=parts[1]
                word=parts[3]
                with open("translations.csv", "r") as file1:
                    for line1 in file1:
                        parts1 = list(line1.strip().split(","))
                        if parts1[1] == pattern and parts1[3] != word:
                            tup=(parts[3],parts1[3])
                            convert.add(tup)
                        if parts1[3] == pattern and parts1[1] != word:
                            tup=(parts[3],parts1[1])
                            convert.add(tup)
                               
    converted=list(convert)                       
    sortconvert=sorted(converted, key=lambda x: x[0], reverse=False)
    return sortconvert
if len(sys.argv)==4:
    sortconvert=languageconv()
    print(sortconvert)
if len(sys.argv)==5:
    lang1=sys.argv[2]
    lang2=sys.argv[3]
    word=sys.argv[4]
    sorts=languageconv()
    for item in sorts:
        if item[0]==word:
            print(item[1])
            sys.exit(0)
    print("UNK")