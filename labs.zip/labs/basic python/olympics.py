'''
    Olympics Medals
    Author: Saksham Rathi
'''

from argparse import ArgumentParser as ap
import os

parser = ap()
parser.add_argument('--path', type=str, required = True)
args = parser.parse_args()

# dictionary for the data
totalData = {}

# looping through the directory
for fileName in os.listdir(args.path):
    file_path = os.path.join(args.path, fileName)
    with open(file_path, "r") as file:
        for line in file :
            data = line.strip().split("-")
            if len(data) == 4 :
                if data[0] not in totalData :
                    totalData[data[0]] = [int(data[1]), int(data[2]), int(data[3])]
                else :
                    totalData[data[0]][0] += int(data[1])
                    totalData[data[0]][1] += int(data[2])
                    totalData[data[0]][2] += int(data[3])
    # read the file

    # loop through data of file and set the values for the data

# sort as per gold medals and break ties lexicographically

sTotalData = sorted(totalData, key = lambda country : (-totalData[country][0],country))
result = {country : totalData[country] for country in sTotalData}
print(result)