'''
    Geometry (Complex and Polar)
    Author: Saksham Rathi
'''
import math
from complex import Complex
from polar import Polar
# import the classes


def modulus(c:Complex):
    '''return modulus of the complex number'''
    mod = math.sqrt((c.x)**2 + (c.y)**2)
    return mod

def arg(c:Complex):
    '''return arg (angle) of the complex number'''
    if c.x == 0 :
        if c.y > 0 :
            return math.pi/2
        return -(math.pi)/2
    
    return math.atan2(c.y, c.x)

def abscissa(p:Polar):
    '''return abscissa of the polar point'''
    dist = p.r
    angle = p.t
    abscis = dist*(math.cos(angle))
    return abscis
    

def ordinate(p:Polar):
    '''return ordinate of the polar point'''
    dist = p.r
    angle = p.t
    ordin = dist*(math.sin(angle))
    return ordin
    

def distance(z1:Complex, z2:Complex):
    '''distance between points'''
    dist = math.sqrt((z1.x - z2.x)**2 + (z1.y - z2.y)**2)
    # dist = math.sqrt(modulus(z1 - z2))
    return dist
    

if __name__ == '__main__':

    # you can use this area of code to check all the functions manually
    # one example of using the functions has been shown
    # run this using "python3 main.py"
    a = Complex(1,2)
    b = Complex(2,2)
    z = a + b # uses the overloaded add
    print(z)
    # print(modulus(z)) # you can call after you implement
    x = Polar(2,math.pi/3) # uses the overloaded power
    print(x ** 2)
