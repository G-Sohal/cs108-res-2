input_file=$1
paragraph_file=$2

while IFS=":" read -r -a arr; do
    name=${arr[0]}
    roll=${arr[1]}
    sed -e 's/student_name/'${name}'/g' -e 's/roll_no./'${roll}'/g' ${paragraph_file}
done < $input_file


####### OR #########

#!/bin/bash
awk '
BEGIN {
    FS = ":"
    file = ARGV[2]
}
{
    name = $1
    roll = $2

    cmd = "sed -e \"s/student_name/" name "/g\" -e \"s/roll_no/" roll "/g\" " file
    system(cmd)
    print ""
}
' "$1" "$2"