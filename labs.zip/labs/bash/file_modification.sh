#!/bin/bash

string=$*

files=$(find -type f -iname '*.out')

for file in $files; do
    echo "$string" >> ${file}
done


###### OR ######

#!/bin/bash
files=$(find . -name "*.out")
for file in $files; do
    echo $* >> ${file}
done