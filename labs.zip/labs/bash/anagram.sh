#!/bin/bash
word1=$1
word2=$2
word1=${word1^^}

word2=${word2^^}

if [[ $word1 == $word2 ]]; then
    echo "not anagram"
    exit 1
fi

echo $word2 > tmp.txt

for(( i=0; i<${#word1}; i++)); do
    char=${word1:$i:1}
    sed -i "s/${char}//1" tmp.txt
done

word3=$(cat tmp.txt)
if [[ -z $word3 ]]; then
    echo "anagram"
else
    echo "not anagram"
fi

rm tmp.txt