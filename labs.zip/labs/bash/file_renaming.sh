#!/bin/bash

while read -r line; do
  arr=($line)

  roll=${arr[0]}
  name=${arr[1]}
  
  if [[ -f "${roll}.pdf" ]]; then
    mv "${roll}.pdf" "${roll}_${name}.pdf"
  fi
done < $1


###### OR #####

#!/bin/bash
while read -r line; do
  arr=($line)
  if [[ -e ${arr[0]}.pdf ]]; then
    mv ${arr[0]}.pdf ${arr[0]}_${arr[1]}.pdf
  fi
done < $1