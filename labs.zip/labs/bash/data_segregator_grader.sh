#!/bin/bash

head -1 "$1" > ug23.csv
head -1 "$1"> ug24.csv

grep -E "^23B.*" "$1" >> ug23.csv
grep -E "^24B.*" "$1" >> ug24.csv

grade() {
    local total=$1
    if [[ $total -gt 85 ]]; then
        echo "AA"
    elif [[ $total -gt 65 ]]; then
        echo "AB"
    elif [[ $total -gt 45 ]]; then
        echo "BB"
    elif [[ $total -gt 35 ]]; then
        echo "CC"
    else
        echo "F"
    fi
}

foo() {
    i=0
    tr -d '\r' < $1 > tmp.csv

    cut -d "," -f6 tmp.csv > tmp2.csv

    echo "grades" > grade.csv
    while read -r line; do
        if [[ $i -ne 0 ]]; then
            x=$(grade "$line")
            echo "$x" >> grade.csv
        fi
        (( i+=1 ))
    done < tmp2.csv

    echo $(paste -d "," $1 grade.csv) > $1
    
    rm tmp.csv tmp2.csv grade.csv
}

foo ug23.csv
foo ug24.csv


######### OR ##########
#!/bin/bash
echo "rollno,quiz1,quiz2,midsem,endsem,total-marks,grades" > ug23.csv
echo "rollno,quiz1,quiz2,midsem,endsem,total-marks,grades" > ug24.csv
touch temp23.csv temp24.csv
touch temps23.csv temps24.csv
grep -E "^23" $1 | cut -d ',' -f -6 >> temp23.csv
grep -E "^24" $1 | cut -d ',' -f -6 >> temp24.csv
while IFS=',' read -r -a arr; do
    arr[5]=$(echo "${arr[5]}" | tr -d '\r')
    if [[ ${arr[5]} > "85" ]]; then
    arr[6]="AA"
    elif [[ ${arr[5]} > "65" ]]; then
    arr[6]="AB"
    elif [[ ${arr[5]} > "45" ]]; then
    arr[6]="BB"
    elif [[ ${arr[5]} > "35" ]]; then
    arr[6]="CC"
    else 
    arr[6]="F"
    fi
    echo "${arr[0]},${arr[1]},${arr[2]},${arr[3]},${arr[4]},${arr[5]},${arr[6]}" >> temps23.csv
done < temp23.csv
while IFS=',' read -r -a arr; do
    arr[5]=$(echo "${arr[5]}" | tr -d '\r')
    if [[ ${arr[5]} > "85" ]]; then
    arr[6]="AA"
    elif [[ ${arr[5]} > "65" ]]; then
    arr[6]="AB"
    elif [[ ${arr[5]} > "45" ]]; then
    arr[6]="BB"
    elif [[ ${arr[5]} > "35" ]]; then
    arr[6]="CC"
    else 
    arr[6]="F"
    fi
    echo "${arr[0]},${arr[1]},${arr[2]},${arr[3]},${arr[4]},${arr[5]},${arr[6]}" >> temps24.csv
done < temp24.csv
sort -t ',' -k7,7 -k1,1n temps23.csv >> ug23.csv
sort -t ',' -k7,7 -k1,1n temps24.csv >> ug24.csv

####Sort the temp.csv file first by the 7th column (alphabetically),
####if there are ties, sort those by the 1st column (numerically)

rm temp23.csv
rm temp24.csv
rm temps23.csv
rm temps24.csv